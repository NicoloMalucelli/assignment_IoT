#ifndef __POT__
#define __POT__

class Pot{

    public:
        virtual int getValue() = 0;

};

#endif