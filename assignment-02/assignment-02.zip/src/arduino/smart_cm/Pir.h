#ifndef __PIR__
#define __PIR__

class Pir{
    public: 
        virtual bool isDetected() = 0;
        virtual bool isReady() = 0;
};

#endif