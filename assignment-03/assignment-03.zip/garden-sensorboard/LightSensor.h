#ifndef __LIGHT_SENSOR__
#define __LIGHT_SENSOR__

class LightSensor{
    public:
        virtual int getValue() = 0;
};

#endif