package btlib.exceptions;

public class BluetoothDeviceNotFound extends Exception { }
